package com.nishasoni;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoupoanserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
